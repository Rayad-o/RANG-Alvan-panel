// آدرس API از config.js خوانده می‌شود (خالی = هم‌منشأ با Backend)
const API_URL = (window.ENV && window.ENV.API_URL) || "";

if (window.Scenes) Scenes.background(document.getElementById("bgCanvas"));

// کاربری که قبلاً وارد شده است مستقیم به داشبورد می‌رود
if (localStorage.getItem("access_token") && localStorage.getItem("user")) {
    window.location.replace("dashboard.html");
}

document.getElementById("loginForm").addEventListener("submit", async function (e) {
    e.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const errorMessage = document.getElementById("errorMessage");
    const button = document.getElementById("loginBtn");

    errorMessage.textContent = "";
    button.disabled = true;
    button.textContent = "در حال ورود...";

    try {
        const response = await fetch(`${API_URL}/auth/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password }),
        });

        const data = await response.json().catch(() => ({}));

        if (!response.ok) {
            errorMessage.textContent = typeof data.detail === "string" ? data.detail : "ورود ناموفق بود";
            return;
        }

        localStorage.setItem("access_token", data.access_token);
        localStorage.setItem("user", JSON.stringify(data.user));
        window.location.href = "dashboard.html";
    } catch (error) {
        errorMessage.textContent = "خطا در اتصال به سرور. مطمئن شوید Backend روشن است.";
        console.error(error);
    } finally {
        button.disabled = false;
        button.textContent = "ورود";
    }
});
